import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./components/**/*.{js,ts,jsx,tsx,mdx}",
    "./app/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        'luna-gold': '#D8B15A',
        'luna-blue': '#0B1F3A',
        'luna-violet': '#2B0F3A',
      },
    },
  },
  plugins: [],
};

export default config;
