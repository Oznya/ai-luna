/** @type {import('next').NextConfig} */
const nextConfig = {
  // Cloudflare Pages configuration
  experimental: {
    runtime: 'edge',
  },
};

export default nextConfig;
