# 🌙 AI Luna - Widget de Calcul de Signe Lunaire

Un widget conversationnel mystique pour découvrir votre signe lunaire, basé sur le livre *"Sous quelle lune êtes-vous née?"* de Diane Boyer.

## ✨ Fonctionnalités

- **Conversation IA** avec Luna, guide spirituelle bienveillante
- **Calcul du signe lunaire** à partir de votre date de naissance
- **Design mystique** avec ciel étoilé animé
- **Deux modes d'intégration** : pastille flottante ou iframe

## 🚀 Déploiement sur Cloudflare Pages

### 1. Variables d'environnement

Dans Cloudflare Pages → Settings → Environment variables, ajoutez :

```
GROQ_API_KEY=votre_cle_api_groq
```

### 2. Configuration du build

- **Framework preset** : Next.js
- **Build command** : `npm run build`
- **Build output directory** : `.next`

## 📋 Intégration sur Systeme.io

### Version Iframe (recommandée)

```html
<iframe 
  src="https://votre-domaine.pages.dev/embed" 
  width="100%" 
  height="600px" 
  frameborder="0"
  style="border-radius: 16px;">
</iframe>
```

## 🎨 Palette de couleurs

- **Or alchimique** : `#D8B15A`
- **Bleu nuit** : `#0B1F3A`
- **Violet nuit** : `#2B0F3A`

## 📚 Crédits

Basé sur le livre *"Sous quelle lune êtes-vous née?"* de **Diane Boyer**

---

*Développé avec ❤️ et un soupçon de magie lunaire*
